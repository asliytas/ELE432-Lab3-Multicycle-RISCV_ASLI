// top.sv
// ELE 432 Lab 3 - Top level for multicycle RISC-V (matches the supplied testbench).
// Testbench instantiates: top dut(clk, reset, WriteData, DataAdr, MemWrite);

module top (input  logic        clk, reset,
            output logic [31:0] WriteData,
            output logic [31:0] DataAdr,
            output logic        MemWrite);

    logic [31:0] ReadData;

    // Multicycle processor core
    riscv rvcore (.clk(clk), .reset(reset),
                  .Adr(DataAdr), .MemWrite(MemWrite),
                  .WriteData(WriteData), .ReadData(ReadData));

    // Unified instruction/data memory
    mem mem_inst (.clk(clk), .we(MemWrite),
                  .a(DataAdr), .wd(WriteData), .rd(ReadData));

endmodule
