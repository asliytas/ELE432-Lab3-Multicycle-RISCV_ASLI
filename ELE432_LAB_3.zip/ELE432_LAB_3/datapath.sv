// datapath.sv
// ELE 432 Lab 3 - Multicycle RISC-V datapath (Figure 1 of the lab handout)

module datapath (input  logic        clk, reset,
                 // control signals from controller
                 input  logic        PCWrite,
                 input  logic        AdrSrc,
                 input  logic        IRWrite,
                 input  logic        RegWrite,
                 input  logic [1:0]  ResultSrc,
                 input  logic [1:0]  ALUSrcA,
                 input  logic [1:0]  ALUSrcB,
                 input  logic [2:0]  ALUControl,
                 input  logic [1:0]  ImmSrc,
                 // status signals to controller
                 output logic        Zero,
                 output logic [6:0]  op,
                 output logic [2:0]  funct3,
                 output logic        funct7b5,
                 // memory interface
                 output logic [31:0] Adr,
                 output logic [31:0] WriteData,
                 input  logic [31:0] ReadData);

    // internal datapath signals
    logic [31:0] PC, OldPC;
    logic [31:0] Instr;          // captured instruction
    logic [31:0] Data;           // memory read data register
    logic [31:0] A;              // RD1 register (rs1 value)
    logic [31:0] RD1, RD2;
    logic [31:0] ImmExt;
    logic [31:0] SrcA, SrcB;
    logic [31:0] ALUResult, ALUOut;
    logic [31:0] Result;

    // ---- PC register (enabled by PCWrite) ----
    flopenr #(32) pcreg   (clk, reset, PCWrite, Result, PC);

    // ---- Address mux (PC for fetch, ALUOut for memory access) ----
    mux2 #(32)   adrmux  (PC, ALUOut, AdrSrc, Adr);

    // ---- OldPC and Instruction Register (both clocked when IRWrite) ----
    flopenr #(32) oldpcreg(clk, reset, IRWrite, PC,       OldPC);
    flopenr #(32) irreg   (clk, reset, IRWrite, ReadData, Instr);

    // ---- Data register: ReadData latched every cycle ----
    flopr  #(32)  datareg (clk, reset, ReadData, Data);

    // ---- Status outputs to controller ----
    assign op       = Instr[6:0];
    assign funct3   = Instr[14:12];
    assign funct7b5 = Instr[30];

    // ---- Register File ----
    regfile rf (clk, RegWrite,
                Instr[19:15], Instr[24:20], Instr[11:7],
                Result, RD1, RD2);

    // ---- Sign extender ----
    extend ext (Instr, ImmSrc, ImmExt);

    // ---- A and WriteData registers (latch RD1 / RD2 each cycle) ----
    flopr #(32) areg   (clk, reset, RD1, A);
    flopr #(32) wdreg  (clk, reset, RD2, WriteData);

    // ---- ALU input muxes ----
    // SrcA: 00 = PC, 01 = OldPC, 10 = A
    mux3 #(32) srcamux (PC, OldPC, A, ALUSrcA, SrcA);
    // SrcB: 00 = WriteData, 01 = ImmExt, 10 = 4
    mux3 #(32) srcbmux (WriteData, ImmExt, 32'd4, ALUSrcB, SrcB);

    // ---- ALU ----
    alu alu_inst (SrcA, SrcB, ALUControl, ALUResult, Zero);

    // ---- ALUOut register ----
    flopr #(32) aluoutreg (clk, reset, ALUResult, ALUOut);

    // ---- Result mux ----
    // ResultSrc: 00 = ALUOut, 01 = Data, 10 = ALUResult (used for fetch PC+4)
    mux3 #(32) resultmux (ALUOut, Data, ALUResult, ResultSrc, Result);

endmodule
