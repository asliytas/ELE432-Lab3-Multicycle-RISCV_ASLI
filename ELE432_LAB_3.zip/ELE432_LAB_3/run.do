# run.do  -  ELE 432 Lab 3 Multicycle RISC-V
# Questa Altera Starter FPGA Edition icin derleme + waveform script'i
# Kullanim: Questa transcript penceresinde
#   cd <bu klasor>
#   do run.do

# Eski calismayi temizle
if {[file exists work]} { vdel -all }
vlib work

# SystemVerilog kaynaklari (bagimliliktan once gelene gore)
vlog -sv building_blocks.sv
vlog -sv datapath.sv
vlog -sv controller.sv
vlog -sv riscv.sv
vlog -sv mem.sv
vlog -sv top.sv
vlog -sv riscv_testbench.sv

# Simulasyon
vsim -voptargs=+acc work.testbench

# Lab'in istedigi waveform sirasi:
# clk, reset, PC, Instr, state, SrcA, SrcB, ALUResult, Adr, WriteData, MemWrite
# Hepsi hex radix.
add wave -radix binary    sim:/testbench/clk
add wave -radix binary    sim:/testbench/reset
add wave -radix hex       sim:/testbench/dut/rvcore/dp/PC
add wave -radix hex       sim:/testbench/dut/rvcore/dp/Instr
add wave -radix unsigned  sim:/testbench/dut/rvcore/c/mfsm/state
add wave -radix hex       sim:/testbench/dut/rvcore/dp/SrcA
add wave -radix hex       sim:/testbench/dut/rvcore/dp/SrcB
add wave -radix hex       sim:/testbench/dut/rvcore/dp/ALUResult
add wave -radix hex       sim:/testbench/dut/DataAdr
add wave -radix hex       sim:/testbench/dut/WriteData
add wave -radix binary    sim:/testbench/dut/MemWrite

# Tabloyu doldurmaya yardimci ek sinyaller
add wave -divider "Helper signals"
add wave -radix hex       sim:/testbench/dut/rvcore/dp/ALUOut
add wave -radix hex       sim:/testbench/dut/rvcore/dp/Result
add wave -radix hex       sim:/testbench/dut/rvcore/dp/A
add wave -radix hex       sim:/testbench/dut/rvcore/dp/ImmExt

run 2000 ns
wave zoom full
