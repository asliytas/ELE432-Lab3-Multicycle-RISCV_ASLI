// building_blocks.sv
// ELE 432 Lab 3 - Multicycle RISC-V (Reusable building blocks)
// Based on Harris & Harris, "Digital Design and Computer Architecture: RISC-V Ed."

// -------------------- Resettable flip-flop --------------------
module flopr #(parameter WIDTH = 8)
              (input  logic              clk, reset,
               input  logic [WIDTH-1:0]  d,
               output logic [WIDTH-1:0]  q);
    always_ff @(posedge clk, posedge reset)
        if (reset) q <= '0;
        else       q <= d;
endmodule


// -------------------- Resettable + enable flip-flop --------------------
module flopenr #(parameter WIDTH = 8)
                (input  logic              clk, reset, en,
                 input  logic [WIDTH-1:0]  d,
                 output logic [WIDTH-1:0]  q);
    always_ff @(posedge clk, posedge reset)
        if      (reset) q <= '0;
        else if (en)    q <= d;
endmodule


// -------------------- Plain enable flip-flop (no reset) --------------------
module flopen #(parameter WIDTH = 8)
               (input  logic              clk, en,
                input  logic [WIDTH-1:0]  d,
                output logic [WIDTH-1:0]  q);
    always_ff @(posedge clk)
        if (en) q <= d;
endmodule


// -------------------- 2:1 mux --------------------
module mux2 #(parameter WIDTH = 8)
             (input  logic [WIDTH-1:0] d0, d1,
              input  logic             s,
              output logic [WIDTH-1:0] y);
    assign y = s ? d1 : d0;
endmodule


// -------------------- 3:1 mux --------------------
module mux3 #(parameter WIDTH = 8)
             (input  logic [WIDTH-1:0] d0, d1, d2,
              input  logic [1:0]       s,
              output logic [WIDTH-1:0] y);
    assign y = (s == 2'b00) ? d0 :
               (s == 2'b01) ? d1 :
               (s == 2'b10) ? d2 : {WIDTH{1'bx}};
endmodule


// -------------------- 32-register x 32-bit register file --------------------
// Reads asynchronously, writes synchronously on rising clk edge.
// x0 (a3==0) reads as 0; writes to x0 are silently dropped.
module regfile (input  logic        clk,
                input  logic        we3,
                input  logic [4:0]  a1, a2, a3,
                input  logic [31:0] wd3,
                output logic [31:0] rd1, rd2);

    logic [31:0] rf[31:0];

    // synchronous write
    always_ff @(posedge clk)
        if (we3 && (a3 != 5'b0))
            rf[a3] <= wd3;

    // asynchronous reads, x0 hardwired to 0
    assign rd1 = (a1 == 5'b0) ? 32'b0 : rf[a1];
    assign rd2 = (a2 == 5'b0) ? 32'b0 : rf[a2];
endmodule


// -------------------- Adder --------------------
module adder (input  logic [31:0] a, b,
              output logic [31:0] y);
    assign y = a + b;
endmodule


// -------------------- Sign-extend / Immediate generator --------------------
// ImmSrc encoding (Harris & Harris Table 7.5):
//   00 : I-type  -> {{20{instr[31]}}, instr[31:20]}
//   01 : S-type  -> {{20{instr[31]}}, instr[31:25], instr[11:7]}
//   10 : B-type  -> {{20{instr[31]}}, instr[7], instr[30:25], instr[11:8], 1'b0}
//   11 : J-type  -> {{12{instr[31]}}, instr[19:12], instr[20], instr[30:21], 1'b0}
// NOTE: input is instr[31:7] (25 bits), as in the textbook.
module extend (input  logic [31:0] instr,
               input  logic [1:0]  immsrc,
               output logic [31:0] immext);
    always_comb
        case (immsrc)
            2'b00: immext = {{20{instr[31]}}, instr[31:20]};                              // I-type
            2'b01: immext = {{20{instr[31]}}, instr[31:25], instr[11:7]};                 // S-type
            2'b10: immext = {{20{instr[31]}}, instr[7], instr[30:25], instr[11:8], 1'b0}; // B-type
            2'b11: immext = {{12{instr[31]}}, instr[19:12], instr[20], instr[30:21], 1'b0}; // J-type
            default: immext = 32'bx;
        endcase
endmodule


// -------------------- ALU --------------------
// ALUControl encoding (from ALU Decoder, Table 7.3):
//   000 : add
//   001 : sub
//   010 : and
//   011 : or
//   101 : slt (signed)
module alu (input  logic [31:0] a, b,
            input  logic [2:0]  alucontrol,
            output logic [31:0] result,
            output logic        zero);

    logic [31:0] sum;
    logic        v;   // overflow (unused externally, kept for completeness)
    logic        isAddSub;

    assign isAddSub  = ~alucontrol[2] & ~alucontrol[1] |
                       ~alucontrol[1] &  alucontrol[0];

    // For sub/slt we add a + (~b) + 1
    assign sum = a + (alucontrol[0] ? ~b : b) + {31'b0, alucontrol[0]};

    always_comb
        case (alucontrol)
            3'b000: result = sum;                                  // add
            3'b001: result = sum;                                  // sub
            3'b010: result = a & b;                                // and
            3'b011: result = a | b;                                // or
            3'b101: result = {31'b0, sum[31] ^ v};                 // slt (signed)
            default: result = 32'bx;
        endcase

    assign zero = (result == 32'b0);
    assign v    = ~(alucontrol[0] ^ a[31] ^ b[31]) & (a[31] ^ sum[31]) & isAddSub;
endmodule
