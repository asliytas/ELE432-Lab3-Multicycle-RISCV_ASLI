# ELE 432 Lab 3 - Multicycle RISC-V Processor

## Dosya yapisi
- `building_blocks.sv` - flopr, flopenr, mux2, mux3, regfile, alu, extend, adder
- `datapath.sv`        - Sekil 1'deki multicycle datapath
- `controller.sv`      - Main FSM (Moore) + ALU Decoder + Instr Decoder
- `riscv.sv`           - controller + datapath sarmalayicisi
- `mem.sv`             - tek birlesik instruction/data bellek (64 kelime)
- `top.sv`             - testbench'in bekledigi top modul
- `memfile.txt`        - bellegin baslangic icerigi (riscvtest.txt'in kopyasi)
- `riscv_testbench.sv` - hocanin verdigi testbench
- `run.do`             - Questa derleme + waveform script'i

## Questa'da nasil calistirilir
1. Questa'yi ac.
2. `File -> Change Directory` ile bu klasore gel (veya transcript'e
   `cd C:/sizin/yolunuz/lab3` yazin).
3. Transcript'e:  `do run.do`
4. Waveform penceresi acilacak ve transcript'te:
       Simulation succeeded
   yazisini gormelisin.

## Beklenen sonuc
riscvtest.s programi sirayla calisir, son komutta `mem[100] = 25` yazilir.
Testbench bunu yakalayinca "Simulation succeeded" basar ve `$stop` cagrir.

## Sinyal radikslerini hex yapma (waveform'da)
Run sirasinda waveform'da sag tik -> Radix -> Hexadecimal.
run.do zaten ana sinyaller icin hex'i ayarliyor.
