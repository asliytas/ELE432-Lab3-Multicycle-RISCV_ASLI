// controller.sv
// ELE 432 Lab 3 - Multicycle RISC-V Controller
// = Main FSM (Moore) + ALU Decoder + Instruction Decoder
// FSM diagram: Harris & Harris, Figure 7.45

module controller (input  logic       clk, reset,
                   // status inputs from datapath
                   input  logic [6:0] op,
                   input  logic [2:0] funct3,
                   input  logic       funct7b5,
                   input  logic       Zero,
                   // control outputs to datapath
                   output logic       PCWrite,
                   output logic       AdrSrc,
                   output logic       MemWrite,
                   output logic       IRWrite,
                   output logic       RegWrite,
                   output logic [1:0] ResultSrc,
                   output logic [1:0] ALUSrcA,
                   output logic [1:0] ALUSrcB,
                   output logic [2:0] ALUControl,
                   output logic [1:0] ImmSrc);

    // -------- internal signals --------
    logic [1:0] ALUOp;
    logic       Branch, PCUpdate;

    // -------- sub-module instantiations --------
    mainfsm     mfsm  (clk, reset, op,
                       Branch, PCUpdate,
                       RegWrite, MemWrite,
                       IRWrite, AdrSrc,
                       ResultSrc, ALUSrcA, ALUSrcB,
                       ALUOp);

    aludec      ad    (op[5], funct3, funct7b5, ALUOp, ALUControl);

    instrdec    id    (op, ImmSrc);

    // -------- PCWrite logic --------
    // PCWrite = (Branch AND Zero) OR PCUpdate    (Harris Fig. 7.28)
    assign PCWrite = (Branch & Zero) | PCUpdate;

endmodule


// =============================================================
// Main FSM (Moore machine, Figure 7.45)
// =============================================================
module mainfsm (input  logic       clk, reset,
                input  logic [6:0] op,
                output logic       Branch, PCUpdate,
                output logic       RegWrite, MemWrite,
                output logic       IRWrite,  AdrSrc,
                output logic [1:0] ResultSrc,
                output logic [1:0] ALUSrcA, ALUSrcB,
                output logic [1:0] ALUOp);

    // state encoding (matches Harris & Harris labels)
    typedef enum logic [3:0] {
        S0_FETCH    = 4'd0,
        S1_DECODE   = 4'd1,
        S2_MEMADR   = 4'd2,
        S3_MEMREAD  = 4'd3,
        S4_MEMWB    = 4'd4,
        S5_MEMWRITE = 4'd5,
        S6_EXECUTER = 4'd6,
        S7_ALUWB    = 4'd7,
        S8_EXECUTEI = 4'd8,
        S9_JAL      = 4'd9,
        S10_BEQ     = 4'd10
    } statetype;

    statetype state, nextstate;

    // ---- state register ----
    always_ff @(posedge clk, posedge reset)
        if (reset) state <= S0_FETCH;
        else       state <= nextstate;

    // ---- next-state logic ----
    always_comb begin
        case (state)
            S0_FETCH:    nextstate = S1_DECODE;
            S1_DECODE:   case (op)
                           7'b0000011: nextstate = S2_MEMADR;   // lw
                           7'b0100011: nextstate = S2_MEMADR;   // sw
                           7'b0110011: nextstate = S6_EXECUTER; // R-type
                           7'b0010011: nextstate = S8_EXECUTEI; // I-type ALU (addi, ...)
                           7'b1100011: nextstate = S10_BEQ;     // beq
                           7'b1101111: nextstate = S9_JAL;      // jal
                           default:    nextstate = S0_FETCH;    // unsupported
                         endcase
            S2_MEMADR:   if (op == 7'b0000011) nextstate = S3_MEMREAD;
                         else                  nextstate = S5_MEMWRITE;
            S3_MEMREAD:  nextstate = S4_MEMWB;
            S4_MEMWB:    nextstate = S0_FETCH;
            S5_MEMWRITE: nextstate = S0_FETCH;
            S6_EXECUTER: nextstate = S7_ALUWB;
            S7_ALUWB:    nextstate = S0_FETCH;
            S8_EXECUTEI: nextstate = S7_ALUWB;
            S9_JAL:      nextstate = S7_ALUWB;
            S10_BEQ:     nextstate = S0_FETCH;
            default:     nextstate = S0_FETCH;
        endcase
    end

    // ---- Moore output logic ----
    // Bundle outputs as a 14-bit vector for clarity
    // {Branch, PCUpdate, RegWrite, MemWrite, IRWrite, AdrSrc,
    //  ResultSrc[1:0], ALUSrcA[1:0], ALUSrcB[1:0], ALUOp[1:0]}
    logic [13:0] controls;
    assign {Branch, PCUpdate, RegWrite, MemWrite, IRWrite, AdrSrc,
            ResultSrc, ALUSrcA, ALUSrcB, ALUOp} = controls;

    always_comb begin
        case (state)
            // Br PCU RW MW IRW AdrSrc | RS  | ALUSA | ALUSB | ALUOp
            S0_FETCH:    controls = 14'b0_1_0_0_1_0_10_00_10_00; // PC <- PC+4, IR <- Mem[PC]
            S1_DECODE:   controls = 14'b0_0_0_0_0_0_00_01_01_00; // ALUOut <- OldPC + Imm (branch/jal target)
            S2_MEMADR:   controls = 14'b0_0_0_0_0_0_00_10_01_00; // ALUOut <- A + Imm
            S3_MEMREAD:  controls = 14'b0_0_0_0_0_1_00_00_00_00; // Adr <- ALUOut, Data <- Mem[Adr]
            S4_MEMWB:    controls = 14'b0_0_1_0_0_0_01_00_00_00; // Result <- Data, RegWrite
            S5_MEMWRITE: controls = 14'b0_0_0_1_0_1_00_00_00_00; // Mem[Adr] <- WriteData
            S6_EXECUTER: controls = 14'b0_0_0_0_0_0_00_10_00_10; // ALUOut <- A op B (R-type)
            S7_ALUWB:    controls = 14'b0_0_1_0_0_0_00_00_00_00; // Result <- ALUOut, RegWrite
            S8_EXECUTEI: controls = 14'b0_0_0_0_0_0_00_10_01_10; // ALUOut <- A op Imm (I-type ALU)
            S9_JAL:      controls = 14'b0_1_0_0_0_0_00_01_10_00; // PC <- branch target, ALUOut <- OldPC+4
            S10_BEQ:     controls = 14'b1_0_0_0_0_0_00_10_00_01; // ALU does A-B; if Zero -> PC <- target
            default:     controls = 14'b0_0_0_0_0_0_00_00_00_00;
        endcase
    end

endmodule


// =============================================================
// ALU Decoder (Harris & Harris Table 7.3)
// =============================================================
module aludec (input  logic       opb5,
               input  logic [2:0] funct3,
               input  logic       funct7b5,
               input  logic [1:0] ALUOp,
               output logic [2:0] ALUControl);

    logic RtypeSub;
    assign RtypeSub = funct7b5 & opb5;   // TRUE for R-type subtract

    always_comb
        case (ALUOp)
            2'b00: ALUControl = 3'b000;                          // add  (lw, sw, jal target+4)
            2'b01: ALUControl = 3'b001;                          // sub  (beq)
            default: case (funct3)                               // R-type or I-type ALU
                3'b000: ALUControl = RtypeSub ? 3'b001 : 3'b000; // sub or add/addi
                3'b010: ALUControl = 3'b101;                     // slt, slti
                3'b110: ALUControl = 3'b011;                     // or,  ori
                3'b111: ALUControl = 3'b010;                     // and, andi
                default: ALUControl = 3'bxxx;
            endcase
        endcase
endmodule


// =============================================================
// Instruction Decoder
// Combinational opcode -> ImmSrc (Harris & Harris Table 7.5/7.6)
// =============================================================
module instrdec (input  logic [6:0] op,
                 output logic [1:0] ImmSrc);
    always_comb
        case (op)
            7'b0000011: ImmSrc = 2'b00; // lw       (I-type)
            7'b0010011: ImmSrc = 2'b00; // I-type ALU (addi,...)
            7'b0100011: ImmSrc = 2'b01; // sw       (S-type)
            7'b1100011: ImmSrc = 2'b10; // beq      (B-type)
            7'b0110011: ImmSrc = 2'b00; // R-type  (don't care)
            7'b1101111: ImmSrc = 2'b11; // jal      (J-type)
            default:    ImmSrc = 2'b00;
        endcase
endmodule
