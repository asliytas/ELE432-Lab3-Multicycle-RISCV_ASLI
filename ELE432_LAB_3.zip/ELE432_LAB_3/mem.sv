// mem.sv
// Unified instruction/data memory for the multicycle RISC-V processor.
// - Word-addressable internally (uses adr[7:2]).
// - Asynchronous read, synchronous write (rising edge).
// - 64 words = 256 bytes.  riscvtest.s only uses addresses 0..0x64.
// - Initial contents are loaded from "memfile.txt" via $readmemh.

module mem (input  logic        clk, we,
            input  logic [31:0] a,
            input  logic [31:0] wd,
            output logic [31:0] rd);

    logic [31:0] RAM [63:0];

    initial
        $readmemh("memfile.txt", RAM);

    // word-aligned: drop bottom 2 bits
    assign rd = RAM[a[31:2]];

    always_ff @(posedge clk)
        if (we) RAM[a[31:2]] <= wd;
endmodule
