// riscv.sv
// ELE 432 Lab 3 - Multicycle RISC-V processor (controller + datapath)

module riscv (input  logic        clk, reset,
              output logic [31:0] Adr,
              output logic        MemWrite,
              output logic [31:0] WriteData,
              input  logic [31:0] ReadData);

    // wires between controller and datapath
    logic        PCWrite, AdrSrc, IRWrite, RegWrite, Zero;
    logic [1:0]  ResultSrc, ALUSrcA, ALUSrcB, ImmSrc;
    logic [2:0]  ALUControl;
    logic [6:0]  op;
    logic [2:0]  funct3;
    logic        funct7b5;

    controller c (.clk(clk), .reset(reset),
                  .op(op), .funct3(funct3), .funct7b5(funct7b5), .Zero(Zero),
                  .PCWrite(PCWrite), .AdrSrc(AdrSrc),
                  .MemWrite(MemWrite), .IRWrite(IRWrite),
                  .RegWrite(RegWrite), .ResultSrc(ResultSrc),
                  .ALUSrcA(ALUSrcA), .ALUSrcB(ALUSrcB),
                  .ALUControl(ALUControl), .ImmSrc(ImmSrc));

    datapath dp (.clk(clk), .reset(reset),
                 .PCWrite(PCWrite), .AdrSrc(AdrSrc),
                 .IRWrite(IRWrite), .RegWrite(RegWrite),
                 .ResultSrc(ResultSrc), .ALUSrcA(ALUSrcA),
                 .ALUSrcB(ALUSrcB), .ALUControl(ALUControl),
                 .ImmSrc(ImmSrc),
                 .Zero(Zero), .op(op), .funct3(funct3), .funct7b5(funct7b5),
                 .Adr(Adr), .WriteData(WriteData),
                 .ReadData(ReadData));

endmodule
